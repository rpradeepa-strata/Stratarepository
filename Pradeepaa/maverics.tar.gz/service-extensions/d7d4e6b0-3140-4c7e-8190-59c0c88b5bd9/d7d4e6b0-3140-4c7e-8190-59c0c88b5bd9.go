package main
import (
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

// Note: To use this service extension with a SAML user flow, the signature must include a response writer.
// Ex. func BuildTokenClaims(api orchestrator.Orchestrator, rw, http.ResponseWriter, _ *http.Request) (map[string]any, error)
func BuildTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Info("se", "Building ID token claims - service-extension")
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return nil, err
	}
	
	mobile, _ := session.GetString("ldap.mobile")
	surname, _ := session.GetString("ldap.sn")
	logger.Info("se-BuildIDTokenClaims", "Successfully loaded custom attributes from sessoin and claims updated")
	return map[string]any{
	    "customhardcodeddummyclaim": "dummy",
		"customermobilefromLdap": mobile,
		"customersurnamefromLdap": surname,
	}, nil
}