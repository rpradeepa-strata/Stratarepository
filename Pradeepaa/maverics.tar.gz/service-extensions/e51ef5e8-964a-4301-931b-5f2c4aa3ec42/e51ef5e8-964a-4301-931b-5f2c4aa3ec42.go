package main

import (
	"fmt"
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

func LoadAttributes(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) error {
    //Configure your Entra ID IDP to have user with email aadkins@strata-eval.io because public LDAP have this user available otherwise login will fail
	logger := api.Logger()
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return err
	}
	logger.Info("se", "loading custom attributes from LDAP")

	mail, err := session.GetString("EntraID-OIDC.email")
	if err != nil {
		return fmt.Errorf("failed to find user email required for LDAP query: %w", err)
	}
	logger.Info("email from entraid", fmt.Sprintf(mail))

	ldap, err := api.AttributeProvider("ldap")
	if err != nil {
		return fmt.Errorf("failed to find user email required for LDAP query: %w", err)
	}
    logger.Info("se", fmt.Sprintf("im here"))
	attrs, err := ldap.Query(mail, []string{"sn", "mobile", "department", "title"})
	if err != nil {
		return fmt.Errorf("failed to query LDAP: %w", err)
	}
    logger.Info("se-attributes from LDAP ", fmt.Sprintf("im here: %w", attrs))
	for k, v := range attrs {
		logger.Info(
			"se", "setting LDAP attribute on session",
			"attribute", k,
			"value", v,
		)
		_ = session.SetString(k, v)
	}

	err = session.Save()
	if err != nil {
        return fmt.Errorf("unable to save session state: %w", err)
	}
	logger.Info("se-LoadAttribute_LDAP", "Successfully loaded custom attributes from LDAP and session updated")
	return nil
}