package main

import (
	"fmt"
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

func CreateHeader(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) (http.Header, error) {
	logger := api.Logger()
	logger.Debug("se", "building custom header")
	
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return nil, err
	}

	mobile, err := session.GetString("ldap.mobile")
	surname, err := session.GetString("ldap.sn")
	if err != nil {
        return nil, fmt.Errorf("unable to retrieve attribute 'azure.givenname': %w", err)
	}
	MobilePhone := fmt.Sprintf("'Custom Header From Session:service-extension' %s", mobile)
	
	return http.Header{
	    "MobilePhoneFromSession": []string{MobilePhone},
	    "SurnameFromSession": []string{surname},
	}, nil
}