package main
 
import (
	"net/http"
 
	"github.com/strata-io/service-extension/orchestrator"
)
 
func CreateHeader(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) (http.Header, error) {
	logger := api.Logger()
	logger.Info("se", "building custom headers")
	email :="sathish.v@ey.gdsindia.com"
	return http.Header{"SM_USER": []string{email}}, nil
}